# Hive Metastore Helm chart

See Helm chart paigaldab Apache Hive Metastore'i Kubernetesesse Superseti ja Trino jaoks. Chart kasutab ametlikku `apache/hive` imaget ja toetab Postgresi ühendust ning skeemi initsialiseerimist.

## Eeldused

- Kubernetes klaster
- Helm v3
- PostgreSQL andmebaas (nt CNPG)
- Secret, kus on JDBC URL, kasutajanimi ja parool (CNPG puhul on olemas)

## Kiire kasutus (Helm)

```sh
helm upgrade --install hms hms-helm -n <namespace> -f <values.yaml>
```

## Kiire kasutus (ArgoCD)

ArgoCD puhul kasuta väärtusfaili, kus schema init on tavaline Job (mitte hook):

```yaml
schemaInit:
  enabled: true
  hook:
    enabled: false
  ttlSecondsAfterFinished: 3600
```

## Olulised väärtused

### Andmebaas

```yaml
database:
  secretName: "hms-db-test-app"
  urlKey: "jdbc-uri"
  userKey: "username"
  passwordKey: "password"
  urlStripQuery: true
```

`urlKey` peab viitama Secreti võtmele, mille väärtus on JDBC URL. Oodatud formaat:

- `jdbc:postgresql://<host>:<port>/<db>`
- CNPG default annab sageli `jdbc:postgresql://.../<db>?user=...&password=...` (sel juhul kasuta `urlStripQuery: true`)

Alternatiivina saad JDBC URL-i anda otse väärtusena, sel juhul `urlKey` ei kasutata:

```yaml
database:
  jdbcUrl: "jdbc:postgresql://hms-db-test-rw.hms-test.svc.cluster.local:5432/hms-db"
```

`urlStripQuery: true` eemaldab JDBC URL-ist `?user=...&password=...` osa. See on kasulik CNPG default secretite puhul.

### Schema init

Vaikimisi kasutatakse `-initOrUpgradeSchema`, et korduv käivitamine ei tekitaks vigu.

```yaml
schemaInit:
  enabled: true
  command:
    - /opt/hive/bin/schematool
    - -initOrUpgradeSchema
    - -dbType
    - postgres
```

### JDBC driver (init container)

Chart toetab init-containerit, mis laeb PostgreSQL JDBC driveri ja lisab selle HMS classpath'i.

```yaml
jdbcDriver:
  enabled: true
  mode: initContainer
  mountDir: /opt/hive/extra-lib
  fileName: postgresql.jar
  hiveAuxJarsPath: /opt/hive/extra-lib/postgresql.jar
  driverVersion: "42.7.3"
  initContainer:
    image:
      repository: curlimages/curl
      tag: "8.8.0"
      pullPolicy: IfNotPresent
    downloadUrl: ""
```

Kui `downloadUrl` on tühi, ehitatakse see automaatselt `driverVersion` põhjal.

Ametlik PostgreSQL JDBC driver:
- https://jdbc.postgresql.org/download/

### hive-site.xml renderdamine

Hive'i konfiguratsioon renderdatakse init-containeris, et vältida secrets väärtuste otse ConfigMap'i kirjutamist.

```yaml
hiveSite:
  render:
    enabled: true
```

## Täielik näidis (ArgoCD)

Vaata `helm-values/hms-argocd-values.yaml`.

## Keskkonna spetsiifilised näited

### Test (CNPG, ArgoCD)

```yaml
database:
  secretName: "hms-db-test-app"
  urlKey: "jdbc-uri"
  userKey: "username"
  passwordKey: "password"
  urlStripQuery: true

schemaInit:
  enabled: true
  hook:
    enabled: false
  ttlSecondsAfterFinished: 3600
  annotations:
    argocd.argoproj.io/sync-options: "Prune=false"

jdbcDriver:
  enabled: true
  mode: initContainer
  mountDir: /opt/hive/extra-lib
  fileName: postgresql.jar
  hiveAuxJarsPath: /opt/hive/extra-lib/postgresql.jar
  driverVersion: "42.7.3"
  initContainer:
    image:
      repository: curlimages/curl
      tag: "8.8.0"
      pullPolicy: IfNotPresent
    downloadUrl: ""
```

### Prod (näidis)

```yaml
database:
  secretName: "hms-db-prod-app"
  urlKey: "jdbc-uri"
  userKey: "username"
  passwordKey: "password"
  urlStripQuery: true

schemaInit:
  enabled: false

resources:
  requests:
    cpu: "250m"
    memory: "512Mi"
  limits:
    cpu: "1"
    memory: "2Gi"
```

## Märkused

- Kui postgresql andmebaasis schema on juba loodud, kasuta `schemaInit.enabled: false` või `-initOrUpgradeSchema`.
